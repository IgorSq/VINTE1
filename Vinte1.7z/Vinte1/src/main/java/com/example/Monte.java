package com.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Monte {
    private List<Carta> cartas = new ArrayList<>();

    public Monte(){
        for(Naipe naipe : Naipe.values()) {
            for(int numero=1;numero<=13;numero++){
                cartas.add (new Carta(numero, naipe));
            }
        }
        embaralhar();
    }

    public Carta virar(){
        return cartas.remove(0);
    }

    public void embaralhar(){
        Collections.shuffle(cartas);
    }
}