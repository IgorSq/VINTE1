package com.example;

public class Jogo {
    protected Monte monte = new Monte();
    protected Jogador jogador = new Jogador();
    protected Computador computador = new Computador();

    public Jogo() {
        monte.embaralhar();
    }

    public Carta distribuiCartaParaJogador(Jogador jogador) {
        if(jogador.parou()) return null;

        Carta carta = monte.virar();
        jogador.receberCarta(carta);

        return carta;
    }

    public boolean acabou(){
        return this.computador.parou() && this.jogador.parou() || jogador.getPontos() > 21 || computador.getPontos() > 21; 
    }

    public String resultado(){
        if(!this.acabou()) return null;
        String resultado = "";
        
        if(this.jogador.getPontos() < this.computador.getPontos() && this.computador.getPontos() <= 21 || this.jogador.getPontos() > 21){
            resultado = "Você perdeu";
        }
        
        if(this.computador.getPontos() < this.jogador.getPontos() && this.jogador.getPontos() <= 21 || this.computador.getPontos() > 21)
            resultado = "Você ganhou";   
        
        if(this.computador.getPontos() == this.jogador.getPontos() || this.computador.getPontos() > 21 && this.jogador.getPontos() > 21)
            resultado = "Empate";

        return resultado;
    }

    public Jogador getJogador() {
        return jogador;
    }

    public Computador getComputador() {
        return computador;
    }
    
}
