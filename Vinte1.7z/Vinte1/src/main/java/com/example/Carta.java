package com.example;

public class Carta {
    private int numero;
    private Naipe naipe;

    public Carta(int numero, Naipe naipe){
        this.numero = numero;
        this.naipe = naipe;
    }

    private String convertCard(int numero){
        String carta = Integer.toString(numero);
        switch (numero) {
            case 1:
                carta = "Ace";
                break;
            case 11:
                carta = "Jack";
                break;
            case 12:
                carta = "Queen";
                break;
            case 13:
                carta = "King";
                break;
        }
        return carta;
    }

    public String imagePath() {
        String carta = convertCard(numero);

        return "classic-cards/" + carta + naipe + ".png";
    }

    public int getNumero() {
        return numero;
    }

    public Naipe getNaipe() {
        return naipe;
    }
}
